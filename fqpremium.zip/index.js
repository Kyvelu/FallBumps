const {Panel} = require("@akarui/aoi.panel")

const aoijs = require("aoi.js")

const bot = new aoijs.Bot({
	token: "MTA0MTg5NjgzMTgzMzA4ODA2MA.GH0kQ_.CVYYXeHRmJGxdrruhG7WxI_bzA6dJ3HpOg6ldQ",
	prefix: ".",
	intents: "all"
})

const panel = new Panel({
    username: "admin",
    password: "admin",
    secret: require('crypto').randomBytes(16).toString("hex"),
    port: 2013,
    bot: bot,
    mainFile: "index.js",
    commands: "./commands",
    interaction:"./interactions"
})
panel.loadPanel()

panel.onError()

bot.onMessage()

bot.variables({
})

bot.status({
    text: "Fqcxn Premium",
    type: "PLAYING"
})

bot.readyCommand({
    channel: "1041900937473708112",
    code: `
Bot online! **$userTag[$clientID]**
$log[Ready On $userTag[$clientID]]

$createApplicationCommand[global;ping;Bot Latency;true]
$createApplicationCommand[global;uptime;Bot Uptime;true]
$createApplicationCommand[global;help;Help Menu;true]
`
})

bot.guildJoinCommand({
channel: "1041931497550127204",
code: `$title[New Server]
$description[I have been added to the server **$serverName**]
Invite: $getServerInvite
`
})

bot.guildLeaveCommand({
channel: "1041931497550127204",
code: `
I have been kicked out of **$serverName**
Server Invite: $getServerInvite
`
})

bot.interactionCommand({
name: "ping",
prototype : 'slash',
code: `
$interactionReply[The Bot's Ping Is *$ping* ms]
` 
})

bot.interactionCommand({
name: "uptime",
prototype : 'slash',
code: `
$interactionReply[The Bot's Uptime Is $uptime]
` 
})

bot.interactionCommand({
name: "help",
prototype: 'slash',
code: `$interactionReply[
;{newEmbed:{title:Help Menu}{description:Do you need help?}{color:FF0000}}
;;;;no]`
})

bot.onInteractionCreate()
const loader = new aoijs.LoadCommands(bot)
loader.load(bot.cmd,"./commands/")